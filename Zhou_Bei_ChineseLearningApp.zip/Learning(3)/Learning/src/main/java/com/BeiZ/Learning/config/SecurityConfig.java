package com.BeiZ.Learning.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.web.filter.CharacterEncodingFilter;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)//开启方法授权的检测
public class SecurityConfig extends WebSecurityConfigurerAdapter  {

    @Autowired
    private UserDetailServiceImpl userDetailService;

    //配置密码加密的方式
    @Bean
    public PasswordEncoder passwordEncoder(){
        //NoOpPasswordEncoder.getInstance()获取一个无加密的实例
//        return NoOpPasswordEncoder.getInstance();
        //返回此加密的编码器之后, 用户输入的密码会通过此编码器加密之后再和数据库里面的
        //密码进行比较
        return new BCryptPasswordEncoder();
    }

    @Bean  //添加此注解的目的是为了在Controller中自动装配
    @Override
    protected AuthenticationManager authenticationManager() throws Exception {
        return super.authenticationManager();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
                .and()
                .authorizeRequests()  //定义哪些url需要保护，哪些url不需要保护
                .antMatchers("/login", "/register", "/js/*", "/css/*", "/api/users/login", "/api/users/register").permitAll()
                .anyRequest().authenticated()
                .and()
                .sessionManagement().maximumSessions(1)
                .and()
                .and()
                .logout()
                .logoutUrl("/logout")
                .and()
                .formLogin()
                .loginPage("/login")  //定义当需要用户登录时候，转到的登录页面
                .permitAll()
                .defaultSuccessUrl("/greeting").permitAll()
                .and()
                .logout()
                .permitAll()
                // 自动登录
                .and().rememberMe();
        http.csrf().disable();
        //解决中文乱码问题
        CharacterEncodingFilter filter = new CharacterEncodingFilter();
        filter.setEncoding("UTF-8");
        filter.setForceEncoding(true);
        http.addFilterBefore(filter, CsrfFilter.class);
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        /*auth.inMemoryAuthentication()
                .withUser("admin")
                .password("$2a$10$Rxe.O41dj34autGsBGvI6eznT4Zf/XamqwPG7AmK1XaH1iRrQX5HO")
                .roles("USER");*/
        //在内存中创建了一个用户，该用户的名称为user，密码为password，用户角色为USER
        auth.userDetailsService(userDetailService);
    }


    public static void main(String[] args) {

        String rawPassword = "123456";
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(rawPassword);
        System.out.println(encodedPassword);


        String hashPassword = "$2a$10$h4VcvlLaCTFK9AIHo5qLZe7Urdv76GkaU06N.4Gob7.eKjw/gIgJu";
        String originalPassword = "password";
        boolean matched = BCrypt.checkpw(originalPassword, hashPassword);
        System.out.println(matched ? "密码匹配" : "密码不匹配");
    }

}
