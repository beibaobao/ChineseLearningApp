package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.Answer;
import com.BeiZ.Learning.services.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/answers")
public class AnswerController {

    @Autowired
    private AnswerService answerService;

    // GET All Answers
    @GetMapping
    public ResponseEntity<List<Answer>> getAllAnswers() {
        return ResponseEntity.ok(answerService.getAllAnswers());
    }

    // GET Answer by Id
    @GetMapping("/{id}")
    public ResponseEntity<Answer> getAnswerById(@PathVariable Long id) {
        return answerService.getAnswerById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // GET Answers by userId
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Answer>> getAnswersByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(answerService.getAnswersByUserId(userId));
    }

    // GET Answers by questionId
    @GetMapping("/question/{questionId}")
    public ResponseEntity<List<Answer>> getAnswersByQuestionId(@PathVariable Long questionId) {
        return ResponseEntity.ok(answerService.getAnswersByQuestionId(questionId));
    }

// POST Create an Answer
@PostMapping
public ResponseEntity<Answer> createAnswer(@RequestBody Answer answer) {
    return ResponseEntity.ok(answerService.createAnswer(answer));
}

    // PUT Update an Answer
    @PutMapping("/{id}")
    public ResponseEntity<Answer> updateAnswer(@PathVariable Long id, @RequestBody Answer answerDetails) {
        Answer updatedAnswer = answerService.updateAnswer(id, answerDetails);
        if(updatedAnswer == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedAnswer);
    }

    // DELETE an Answer
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAnswer(@PathVariable Long id) {
        answerService.deleteAnswer(id);
        return ResponseEntity.ok().build();
    }
}





