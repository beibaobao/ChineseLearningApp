package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user) {
        User registeredUser = userService.createUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getRole());
        if(registeredUser == null) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok().body(registeredUser);
    }

}
