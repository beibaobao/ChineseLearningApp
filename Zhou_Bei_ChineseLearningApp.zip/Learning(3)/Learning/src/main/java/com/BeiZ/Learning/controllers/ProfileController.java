package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.Profile;
import com.BeiZ.Learning.services.ProfileService;
import com.BeiZ.Learning.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

@RestController
@RequestMapping("/api/profiles")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    // Get a profile by user id
    @GetMapping("/user/{userId}")
    public ResponseEntity<Profile> getProfileByUserId(@PathVariable Long userId) {
        Profile profile = profileService.getProfileByUserId(userId);
        if(profile != null) {
            return ResponseEntity.ok(profile);
        }
        return ResponseEntity.notFound().build();
    }

    // Show profile of the current user in the view
    @GetMapping("/profile")
    public String showProfile(Model model) {
        // Get authenticated user
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = currentUser.getId();

        // Get profile for user
        Profile profile = profileService.getProfileByUserId(userId);
        if (profile != null) {
            model.addAttribute("profile", profile);
            return "profile";
        }

        // Redirect or show error page if no profile found
        return "error";
    }

    // Create a profile
    @PostMapping
    public Profile createProfile(@RequestBody Profile profile) {
        return profileService.createProfile(profile);
    }

    // Update a profile
    @PutMapping("/user/{userId}")
    public ResponseEntity<Profile> updateProfile(@PathVariable Long userId, @RequestBody Profile profileDetails) {
        Profile updatedProfile = profileService.updateProfile(userId, profileDetails);
        if(updatedProfile != null) {
            return ResponseEntity.ok(updatedProfile);
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/progress/{userId}")
    public ResponseEntity<Profile> updateProgress(@PathVariable Long userId, @RequestBody Integer progress) {
        Profile updatedProfile = profileService.updateProgress(userId, progress);
        if(updatedProfile == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedProfile);
    }
}
