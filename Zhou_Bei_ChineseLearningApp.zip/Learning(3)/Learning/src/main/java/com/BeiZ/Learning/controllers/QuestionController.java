package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.exceptions.ResourceNotFoundException;
import com.BeiZ.Learning.models.Question;
import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.services.QuestionService;
import com.BeiZ.Learning.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/questions")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserService userService;

    @PostMapping("")
    public ResponseEntity<Boolean> submit (@RequestBody Map<String, String> body, @AuthenticationPrincipal UserDetails userDetails){
        User user = userService.selectByUserName(userDetails.getUsername());
        if(user != null) {
            Question question = new Question();
            question.setText(body.get("text"));
            question.setUser(user);
            questionService.submit(question);
            return ResponseEntity.ok(true);
        } else {
            // Handle the case where the user isn't found
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Question> getQuestionById(@PathVariable(value = "id") Long questionId) {
        Question question = questionService.getQuestionById(questionId)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id " + questionId));
        return ResponseEntity.ok().body(question);
    }

    @GetMapping("")
    public ResponseEntity<List<Question>> list () {
        List<Question> list = questionService.list();
        return ResponseEntity.ok(list);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Question> updateQuestion(@PathVariable(value = "id") Long questionId, @Valid @RequestBody Question questionDetails) {
        Question question = questionService.getQuestionById(questionId)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id " + questionId));
        question.setText(questionDetails.getText());
        final Question updatedQuestion = questionService.updateQuestion(questionId, question);
        return ResponseEntity.ok(updatedQuestion);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQuestion(@PathVariable(value = "id") Long questionId) {
        Question question = questionService.getQuestionById(questionId)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id " + questionId));
        questionService.deleteQuestion(question.getId());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/user/{userId}")
    public List<Question> getQuestionsByUserId(@PathVariable(value = "userId") Long userId) {
        return questionService.getQuestionsByUserId(userId);
    }
}
