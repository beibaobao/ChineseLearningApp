package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.Question;
import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.services.QuestionService;
import com.BeiZ.Learning.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.security.core.annotation.AuthenticationPrincipal;


@Controller
@RequestMapping("/input")
public class QuestionInputController {

    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserService userService;

    @GetMapping("/questions")
    public String inputQuestions(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        model.addAttribute("newQuestion", new Question());
        return "question_input";
    }

    @PostMapping("/questions")
    public String submitQuestion(@ModelAttribute Question newQuestion, @AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.selectByUserName(userDetails.getUsername());
        if (user != null) {
            newQuestion.setUser(user);
            questionService.submit(newQuestion);
        }
        return "redirect:/input/questions";
    }
}

