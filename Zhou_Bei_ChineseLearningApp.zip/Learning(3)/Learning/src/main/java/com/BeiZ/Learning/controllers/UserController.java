package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.response.ResultVO;
import com.BeiZ.Learning.response.StatusCode;
import com.BeiZ.Learning.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    AuthenticationManager manager;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<User>> getUserById(@PathVariable(value = "id") Long userId) {
        Optional<User> user = userService.getUserById(userId);
        if(user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(user);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        return userService.createUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getRole());
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable(value = "id") Long userId, @RequestBody User userDetails) {
        User updatedUser = userService.updateUser(userId, userDetails);
        if(updatedUser == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(updatedUser);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable(value = "id") Long userId) {
        userService.deleteUser(userId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/login")
    public ResultVO loginUser(@RequestBody User user) {
        System.out.println("开始处理【用户登录】请求,参数: " + user);

            //通过认证管理器启动Security的认证流程  返回认证结果对象
        Authentication result = manager.authenticate(new UsernamePasswordAuthenticationToken(
                    user.getUsername(), user.getPassword()));

        //将认证结果保存到Security上下文中   让Security框架记住登录状态
        SecurityContextHolder.getContext().setAuthentication(result);
        //代码执行到这里时代表登录成功!如果登录失败Security框架会抛出异常
        return ResultVO.ok();
    }

    @PostMapping("/register")
    public ResultVO registerUser(@RequestBody User user) {
        User dbUser = userService.selectByUserName(user.getUsername());
        if(dbUser != null) {
            //代表用户名已存在
            return new ResultVO(StatusCode.USERNAME_ALREADY_EXISTS);
        }

        userService.createUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getRole());
        return ResultVO.ok();
    }

    @RequestMapping("logout")
    public void logout() {
        // 从Security框架中删除认证数据
        SecurityContextHolder.clearContext();
    }

}
