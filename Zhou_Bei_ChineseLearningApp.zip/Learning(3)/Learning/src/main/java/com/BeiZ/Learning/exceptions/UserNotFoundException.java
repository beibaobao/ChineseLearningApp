package com.BeiZ.Learning.exceptions;

public class UserNotFoundException {
}
