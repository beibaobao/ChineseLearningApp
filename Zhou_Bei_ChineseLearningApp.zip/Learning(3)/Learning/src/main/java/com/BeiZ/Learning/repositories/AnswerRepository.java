package com.BeiZ.Learning.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.BeiZ.Learning.models.Answer;

import java.util.List;

@Repository
public interface AnswerRepository extends JpaRepository<Answer, Long> {

    // Find all answers by a specific user id
    List<Answer> findByUserId(Long userId);

    // Find all answers for a specific question id
    List<Answer> findByQuestionId(Long questionId);
}
