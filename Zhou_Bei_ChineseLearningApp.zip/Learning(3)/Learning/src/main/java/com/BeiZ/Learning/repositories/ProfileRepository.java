package com.BeiZ.Learning.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.BeiZ.Learning.models.Profile;

@Repository
public interface ProfileRepository extends JpaRepository<Profile, Long> {

    // Find a Profile by a specific user id
    Profile findByUserId(Long userId);

    // Custom queries could be added here based on your requirements
}
