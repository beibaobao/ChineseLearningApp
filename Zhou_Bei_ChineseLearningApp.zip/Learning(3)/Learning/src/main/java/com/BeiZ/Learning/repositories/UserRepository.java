//package com.BeiZ.Learning.repositories;
//
//import com.BeiZ.Learning.models.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//import java.util.Optional;
//
//@Repository
//public interface UserRepository extends JpaRepository<User, Long> {
//
//
//    // Select user by email
//    @Query("SELECT u FROM User u WHERE u.email = ?1")
//    Optional<User> findByEmail(String email);
//
//    // Select users with a specific role
//    @Query("SELECT u FROM User u WHERE u.role = ?1")
//    List<User> findByRole(String role);
//
//    // Select user by username
//    Optional<User> findByUsername(String username);
//
//    // Check if a user with a particular email exists
//    boolean existsByEmail(String email);
//
//    // Check if a user with a particular username exists
//    boolean existsByUsername(String username);
//
//}



package com.BeiZ.Learning.repositories;

import com.BeiZ.Learning.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Select user by email
    Optional<User> findByEmail(String email);

    // Select users with a specific role
    List<User> findByRole(String role);

    // Select user by username
    Optional<User> findByUsername(String username);

    // Check if a user with a particular email exists
    boolean existsByEmail(String email);

    // Check if a user with a particular username exists
    boolean existsByUsername(String username);

    // This will try to find a user first by username and then by email
    Optional<User> findByUsernameOrEmail(String username, String email);


}

