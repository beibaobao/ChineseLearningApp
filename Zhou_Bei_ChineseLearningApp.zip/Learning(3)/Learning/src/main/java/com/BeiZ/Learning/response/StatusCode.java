package com.BeiZ.Learning.response;

import lombok.Getter;


@Getter
public enum StatusCode {
    SUCCESS(1,"OK"),
    NOT_LOGIN(1000,"Not logged in"),
    LOGIN_SUCCESS(1001,"Login Success"),
    PASSWORD_ERROR(1002,"Wrong password"),
    USERNAME_ERROR(1003,"Wrong username"),
    USERNAME_ALREADY_EXISTS(1004,"Username already existed"),
    FORBIDDEN_ERROR(1005,"No access granted"),

    OPERATION_SUCCESS(2001,"Operation Success"),
    OPERATION_FAILED(2002,"Operation failed"),
    VALIDATE_ERROR(3002, "Validate error");
    private int code;
    private String msg;
    //所有构造方法默认使用private访问修饰符修饰
    StatusCode(){}
    /**构造方法*/
    StatusCode(int code,String msg){
        this.code=code;
        this.msg=msg;
    }
}
