package com.BeiZ.Learning.services;

import com.BeiZ.Learning.models.Answer;
import com.BeiZ.Learning.repositories.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnswerService {

    @Autowired
    private AnswerRepository answerRepository;

    // Get all Answers
    public List<Answer> getAllAnswers() {
        return answerRepository.findAll();
    }

    // Get Answer by id
    public Optional<Answer> getAnswerById(Long id) {
        return answerRepository.findById(id);
    }

    // Get Answers by userId
    public List<Answer> getAnswersByUserId(Long userId) {
        return answerRepository.findByUserId(userId);
    }

    // Get Answers by questionId
    public List<Answer> getAnswersByQuestionId(Long questionId) {
        return answerRepository.findByQuestionId(questionId);
    }

    // Create an Answer
    public Answer createAnswer(Answer answer) {
        return answerRepository.save(answer);
    }

    // Update an Answer
    public Answer updateAnswer(Long id, Answer answerDetails) {
        Optional<Answer> optionalAnswer = answerRepository.findById(id);
        if(optionalAnswer.isPresent()) {
            Answer answer = optionalAnswer.get();
            answer.setText(answerDetails.getText());
            // update other fields as needed

            return answerRepository.save(answer);
        }
        return null;
    }

    // Delete an Answer
    public void deleteAnswer(Long id) {
        Optional<Answer> optionalAnswer = answerRepository.findById(id);
        if(optionalAnswer.isPresent()) {
            answerRepository.delete(optionalAnswer.get());
        }
    }
}
