package com.BeiZ.Learning.services;

import com.BeiZ.Learning.models.Profile;
import com.BeiZ.Learning.repositories.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    // Get a profile by user id
    public Profile getProfileByUserId(Long userId) {
        return profileRepository.findByUserId(userId);
    }

    // Create a Profile
    public Profile createProfile(Profile profile) {
        return profileRepository.save(profile);
    }

    // Update a Profile
    public Profile updateProfile(Long userId, Profile profileDetails) {
        Profile profile = profileRepository.findByUserId(userId);
        if(profile != null) {
            profile.setProgress(profileDetails.getProgress());
            return profileRepository.save(profile);
        }
        return null;
    }
    public Profile updateProgress(Long userId, Integer progress) {
        Optional<Profile> optionalProfile = Optional.ofNullable(profileRepository.findByUserId(userId));
        if(optionalProfile.isPresent()) {
            Profile profile = optionalProfile.get();
            profile.setProgress(profile.getProgress() + progress);
            return profileRepository.save(profile);
        }
        return null;
    }


}
