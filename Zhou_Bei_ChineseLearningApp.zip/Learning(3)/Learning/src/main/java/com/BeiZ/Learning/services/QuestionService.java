package com.BeiZ.Learning.services;

import com.BeiZ.Learning.models.Question;
import com.BeiZ.Learning.repositories.QuestionRepository;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Data
public class QuestionService {
    @Autowired
    private QuestionRepository questionRepository;





    // Get all Questions
    public List<Question> getAllQuestions() {
        List<Question> questions = questionRepository.findAll();
        System.out.println(questions); // just for debugging
        return questions;
    }

    // Get a single Question
    public Optional<Question> getQuestionById(Long questionId) {
        return questionRepository.findById(questionId);
    }

    // Create a new Question
    public Question createQuestion(Question question) {
        return questionRepository.save(question);
    }



    // Update a Question
    public Question updateQuestion(Long questionId, Question questionDetails) {
        Optional<Question> optionalQuestion = questionRepository.findById(questionId);
        if (optionalQuestion.isPresent()) {
            Question question = optionalQuestion.get();
            question.setText(questionDetails.getText()); // here
            return questionRepository.save(question);
        }
        return null;
    }

    // Delete a Question
    public void deleteQuestion(Long questionId) {
        Optional<Question> optionalQuestion = questionRepository.findById(questionId);
        if (optionalQuestion.isPresent()) {
            questionRepository.delete(optionalQuestion.get());
        }
    }

    // Get Questions by user
    public List<Question> getQuestionsByUserId(Long userId) {
        return questionRepository.findByUserId(userId);
    }


    public void submit(Question question) {
        questionRepository.save(question);
    }

    public List<Question> list() {
        return questionRepository.findAll();
    }

}
