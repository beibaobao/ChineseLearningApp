package com.BeiZ.Learning.services;

import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


    // Get All Users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Get a Single User
    public Optional<User> getUserById(Long userId) {
        return userRepository.findById(userId);
    }

    // Update a User
    public User updateUser(Long userId, User userDetails) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setUsername(userDetails.getUsername());
            user.setEmail(userDetails.getEmail());
            if (userDetails.getPassword() != null) {
                user.setPassword(passwordEncoder.encode(userDetails.getPassword()));
            }
            // update other fields as needed

            return userRepository.save(user);
        }
        return null;
    }

    // Delete a User
    public void deleteUser(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            userRepository.delete(optionalUser.get());
        }
    }

    // Create a User
    public User createUser(String username, String password, String email, User.Role role) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password)); // Encrypt the password before saving
        user.setEmail(email);
        user.setRole(role);
        userRepository.save(user);

        return userRepository.save(user);

    }

    /**
     * 根据用户名查询用户信息
     * @param username
     * @return
     */
    public User selectByUserName(String username) {
        Optional<User> byUsername = userRepository.findByUsername(username);
        if(byUsername.isPresent()){
            return byUsername.get();
        }

        return null;
    }
}


