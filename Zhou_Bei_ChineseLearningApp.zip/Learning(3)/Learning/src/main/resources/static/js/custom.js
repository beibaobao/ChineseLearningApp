$(document).ready(function(){
    alert('Welcome to Learn Chinese! Choose a unit to begin.');
});
