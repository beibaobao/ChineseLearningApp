

// This function takes an array of questions and adds them to the page
function displayQuestions(questions) {
    const list = document.getElementById('questions-list');

    // Remove all existing list items
    while (list.firstChild) {
        list.firstChild.remove();
    }

    // Add a new list item for each question
    questions.forEach(question => {
        const li = document.createElement('li');
        li.textContent = question.text;
        list.appendChild(li);
    });
}

// Fetch the initial list of questions when the page loads
function loadQuestions() {
    fetch('/questions')
        .then(response => {
            if (!response.ok) {
                throw new Error("HTTP error " + response.status);
            }
            return response.json();
        })
        .then(displayQuestions)
        .catch(console.error);
}

loadQuestions();

// Add an event listener to the form to submit a new question
document.getElementById('question-form').addEventListener('submit', event => {
    event.preventDefault();

    const textField = document.getElementById('question-text');
    const text = textField.value;

    fetch('/questions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: text }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.json();
    })
    .then(question => {
        // Clear the form
        textField.value = '';

        // Load all questions again
        loadQuestions();
    })
    .catch(console.error);
});
