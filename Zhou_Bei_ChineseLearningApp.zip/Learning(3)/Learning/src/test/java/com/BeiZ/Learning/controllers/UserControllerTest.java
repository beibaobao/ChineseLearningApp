package com.BeiZ.Learning.controllers;

import com.BeiZ.Learning.models.User;
import com.BeiZ.Learning.response.ResultVO;
import com.BeiZ.Learning.services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

// MockitoExtension initializes fields annotated with @Mock
@ExtendWith(MockitoExtension.class)
// SpringBootTest is used to signify that the context under test is a Spring application context. It will be used to bootstrap the entire container.
@SpringBootTest
public class UserControllerTest {

    // @Mock creates a mock instance of the class (UserService in this case).
    @Mock
    private UserService userService;

    // @InjectMocks creates an instance of the class (UserController in this case) and injects the mocks that are created with the @Mock (or @Spy) annotations into this instance.
    @InjectMocks
    private UserController userController;

    private User user1;
    private User user2;

    // @BeforeEach is used to signal that the annotated method should be executed before each @Test method in the current test class.
    @BeforeEach
    public void setUp() {
        user1 = new User();
        user1.setUsername("testUser1");
        user1.setPassword("password1");

        user2 = new User();
        user2.setUsername("testUser2");
        user2.setPassword("password2");
    }

    // @Test signifies that the annotated method is a test method.
    @Test
    public void getAllUsersTest() {
        List<User> expectedUsers = Arrays.asList(user1, user2);
        // Mockito's when-thenReturn construct helps stub a method to return a specific object when called during the test.
        when(userService.getAllUsers()).thenReturn(expectedUsers);

        List<User> actualUsers = userController.getAllUsers();
        // AssertJ's assertThat is a fluent assertion library which provides a more readable code and better failure messages.
        assertThat(actualUsers).isEqualTo(expectedUsers);
    }

    @Test
    public void getUserByIdTest() {
        when(userService.getUserById(1L)).thenReturn(Optional.of(user1));

        ResponseEntity<Optional<User>> actualUser = userController.getUserById(1L);
        assertThat(actualUser.getBody().get()).isEqualTo(user1);
    }

    @Test
    // Test for method createUser
    public void createUserTest() {
        when(userService.createUser(user1.getUsername(), user1.getPassword(), user1.getEmail(), user1.getRole())).thenReturn(user1);

        User createdUser = userController.createUser(user1);
        assertThat(createdUser).isEqualTo(user1);
    }

    @Test
    // Test for method updateUser
    public void updateUserTest() {
        when(userService.updateUser(1L, user1)).thenReturn(user1);

        ResponseEntity<User> updatedUser = userController.updateUser(1L, user1);
        assertThat(updatedUser.getBody()).isEqualTo(user1);
    }


    }





