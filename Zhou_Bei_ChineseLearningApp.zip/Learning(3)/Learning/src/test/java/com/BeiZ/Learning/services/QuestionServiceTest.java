import com.BeiZ.Learning.models.Question;
import com.BeiZ.Learning.repositories.QuestionRepository;
import com.BeiZ.Learning.services.QuestionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class QuestionServiceTest {

    @Mock
    private QuestionRepository questionRepository;

    @InjectMocks
    private QuestionService questionService;

    private Question question1;
    private Question question2;

    @BeforeEach
    public void setUp() {
        question1 = new Question();
        question1.setId(1L);
        question1.setText("Question 1");

        question2 = new Question();
        question2.setId(2L);
        question2.setText("Question 2");
    }

    @Test
    public void getAllQuestionsTest() {
        List<Question> expectedQuestions = Arrays.asList(question1, question2);
        when(questionRepository.findAll()).thenReturn(expectedQuestions);

        List<Question> actualQuestions = questionService.getAllQuestions();
        assertThat(actualQuestions).isEqualTo(expectedQuestions);
    }

    @Test
    public void getQuestionByIdTest() {
        when(questionRepository.findById(1L)).thenReturn(Optional.of(question1));

        Optional<Question> actualQuestion = questionService.getQuestionById(1L);
        assertThat(actualQuestion.get()).isEqualTo(question1);
    }

    @Test
    public void createQuestionTest() {
        when(questionRepository.save(any(Question.class))).thenReturn(question1);

        Question actualQuestion = questionService.createQuestion(question1);
        assertThat(actualQuestion).isEqualTo(question1);
    }

    @Test
    public void updateQuestionTest() {
        when(questionRepository.findById(1L)).thenReturn(Optional.of(question1));
        when(questionRepository.save(any(Question.class))).thenReturn(question1);

        Question actualQuestion = questionService.updateQuestion(1L, question1);
        assertThat(actualQuestion).isEqualTo(question1);
    }


}

